goog.module('types_in_zip');

/** @type {number} */
const num = 12;

/** @type {boolean} */
const bool = false;

/** @type {string} */
const str = 's';

exports = {num, bool, str};
