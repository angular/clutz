goog.provide('class_in_zip');

/**
 * @constructor
 * @param {number} n
 */
class_in_zip.A = function(n) {
  /** @type {number} */
  this.a = n;
};

