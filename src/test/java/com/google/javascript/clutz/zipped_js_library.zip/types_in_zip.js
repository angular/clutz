goog.provide('types_in_zip');

/** @type {number} */
types_in_zip.num = 12;

/** @type {boolean} */
types_in_zip.bool = false;

/** @type {string} */
types_in_zip.str = 's';

